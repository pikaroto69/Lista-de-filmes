from flask import Flask, render_template, request, redirect

app = Flask(__name__)

filmes = []
favorito = False

@app.route('/')
def index():
    print(f"Filmes na página inicial: {filmes}")  # Print de depuração
    return render_template('index.html', filmes=filmes)

@app.route('/adicionar_filme', methods=['GET', 'POST'])
def adicionar_filme():
    """
    Rota para adicionar um novo filme.
    Se o método for POST, adiciona o novo filme à lista.
    Se não, exibe o formulário para adicionar um novo filme.
    """
    if request.method == 'POST':
        nome = request.form['nome']
        telefone = request.form['telefone']
        email = request.form['email']
        favorito = request.form.get('favorito', 'off') == 'on'
        codigo = len(filmes)
        filmes.append([codigo, nome, telefone, email, favorito])
        print(f"Filme adicionado: {filmes[-1]}")  # Print de depuração
        return redirect('/')  # Redireciona de volta para a página inicial
    else:
        return render_template('adicionar_filme.html')  # Renderiza o formulário de adicionar filme

@app.route('/editar_filme/<int:codigo>', methods=['GET', 'POST'])
def editar_filme(codigo):
    """
    Rota para editar um filme existente.
    Se o método for POST, atualiza os detalhes do filme com o ID fornecido.
    Caso contrário, exibe o formulário preenchido com os detalhes do filme para edição.
    """
    if request.method == 'POST':
        nome = request.form['nome']
        telefone = request.form['telefone']
        email = request.form['email']
        favorito = request.form.get('favorito', 'off') == 'on'
        filmes[codigo] = [codigo, nome, telefone, email, favorito]
        return redirect('/')  # Redireciona de volta para a página inicial
    else:
        filme = filmes[codigo]
        return render_template('editar_filme.html', filme=filme)  # Renderiza o formulário de edição

@app.route('/apagar_filme/<int:codigo>')
def apagar_filme(codigo):
    """
    Rota para apagar um filme da lista.
    """
    del filmes[codigo]
    return redirect('/')  # Redireciona de volta para a página inicial

if __name__=='__main__':
    app.run(debug=True)